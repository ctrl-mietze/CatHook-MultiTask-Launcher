# Relay protocol v1

## Device authentication

1. Device opens `wss://HOST/device`.
2. First data frame must be `type=auth` and contains the device token plus hello metadata.
3. Server validates the SHA-256 token hash against the user-bound device record.
4. Server returns `type=welcome` with a fresh `session_id` and heartbeat interval.

Tokens are never placed in the WebSocket URL.

## Heartbeats

The server uses WebSocket ping/pong every 20 seconds. The client may additionally send application heartbeat messages. `last_seen` is persisted.

## Tool requests

Each request has a globally unique `request_id`. The relay keeps a pending-request map. Device responses are accepted only from the same device for an existing pending ID.

## Reconnect / idempotency

The relay waits a reconnect grace interval before failing requests for a disconnected device. A reconnect of the same authenticated `device_id` receives outstanding requests again. The client de-duplicates active and recently completed `request_id`s.

## Limits

- MCP HTTP body: 1 MiB
- device WS message: 1 MiB
- `termux_run` output: 512 KiB combined stdout/stderr
- command timeout: 1–300 seconds
- pairing expiry: default 10 minutes
