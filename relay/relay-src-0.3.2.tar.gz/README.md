# Termux Android Remote Bridge

A real outbound-device bridge between ChatGPT MCP and Termux. It does **not** use OpenAI Secure MCP Tunnel and the Android device does **not** need an OpenAI Runtime/API key.

## Architecture

```text
ChatGPT / MCP client
  -> HTTPS /mcp (OAuth 2.1 + PKCE)
  -> Railway relay
  -> authenticated persistent WSS /device
  -> Termux client
  -> command / audit tool
  -> WSS response with request_id
  -> MCP response
```

The phone always initiates the network connection. No port forwarding, private-IP dialing, or inbound access to Android is required.

## MVP tools

- `termux_status`
- `termux_run`
- `termux_list_audits`
- `termux_read_audit`
- `termux_save_audit`

The relay transport is generic: every device request contains `tool`, `arguments`, and a unique `request_id`, so more tools can be added without redesigning transport.

## Security model

- HTTPS/WSS only in production (Railway terminates TLS)
- OAuth 2.1 authorization-code + PKCE for MCP users
- Dynamic OAuth client registration for ChatGPT developer-mode connections
- one-time device pairing code + independent pairing nonce
- random device token stored only in `~/.termux-android-bridge/auth.json` (`0600`)
- device tokens stored only as SHA-256 hashes server-side
- explicit user/device binding in PostgreSQL
- token rotate + user-side revoke endpoints
- request IDs, session IDs, bounded output, timeouts, rate limiting and reconnect grace
- no secrets written to normal application logs

## Railway

Required variables for the relay service:

```text
NODE_ENV=production
PORT=3000
PUBLIC_BASE_URL=https://<relay-domain>
DATABASE_URL=${{Postgres.DATABASE_URL}}
PGSSLMODE=require
SERVER_SECRET=<random secret>
BRIDGE_USERNAME=<login>
BRIDGE_PASSWORD=<login password>
```

Run with:

```bash
npm install
npm start
```

Health endpoint: `/health`
MCP endpoint: `/mcp`
Device WebSocket: `/device`

## Termux client

Build the `.deb`:

```bash
DEFAULT_RELAY_URL='https://relay.example.com' VERSION=0.3.2 bash scripts/build-deb.sh
```

After installing the CatHook Termux repository, normal installation is:

```bash
pkg update
pkg install termux-android-bridge
```

First pairing:

```bash
termux-setup-storage
termux-android-bridge setup
```

The client prints a one-time pairing code and a HTTPS claim URL. After successful account login, the device token is delivered back only to that waiting client.

Then:

```bash
termux-android-bridge start-bg
termux-android-bridge status
termux-android-bridge doctor
termux-android-bridge logs
```

## Android AuditAi

The client resolves and creates:

```text
~/storage/shared/Documents/AuditAi
```

Reports use unique names and `wx` creation semantics, so existing reports are never overwritten.

## Request protocol

Request:

```json
{
  "type": "tool_request",
  "request_id": "req_uuid",
  "session_id": "uuid",
  "tool": "termux_run",
  "arguments": {"command": "uname -a"}
}
```

Response:

```json
{
  "type": "tool_response",
  "request_id": "req_uuid",
  "success": true,
  "result": {
    "stdout": "...",
    "stderr": "",
    "exit_code": 0,
    "duration_ms": 32
  }
}
```

The client caches recent responses by `request_id`. If the network reconnects during the relay grace window, the relay can resend the same request without re-running a completed command.
