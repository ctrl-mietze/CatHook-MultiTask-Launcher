import http from 'node:http';
import crypto from 'node:crypto';
import { WebSocketServer } from 'ws';
import { createStore, futureIso, nowIso } from './store.mjs';
import { hashPassword, verifyPassword, randomToken, randomCode, sha256, pkceS256, encryptString, decryptString, normalizeBaseUrl } from './security.mjs';
import { DeviceHub } from './deviceHub.mjs';
import { MCP_TOOLS } from './mcp.mjs';

const PORT=Number(process.env.PORT||3000);
const baseUrl=normalizeBaseUrl(process.env.PUBLIC_BASE_URL||`http://127.0.0.1:${PORT}`);
const serverSecret=process.env.SERVER_SECRET||crypto.randomBytes(32).toString('hex');
const bridgeUsername=process.env.BRIDGE_USERNAME||'raphael';
const bridgePassword=process.env.BRIDGE_PASSWORD||'change-me-now';
const accessTtl=Number(process.env.ACCESS_TOKEN_TTL_SECONDS||3600);
const refreshTtl=Number(process.env.REFRESH_TOKEN_TTL_SECONDS||2592000);
const pairTtl=Number(process.env.PAIRING_TTL_SECONDS||600);
const requestTimeoutMs=Number(process.env.REQUEST_TIMEOUT_SECONDS||180)*1000;
const reconnectGraceMs=Number(process.env.RECONNECT_GRACE_SECONDS||20)*1000;
if(process.env.NODE_ENV==='production'){
  if(!process.env.SERVER_SECRET){console.error('SERVER_SECRET is required in production');process.exit(2);}
  if(bridgePassword==='change-me-now'){console.error('BRIDGE_PASSWORD must be changed in production');process.exit(2);}
  if(!process.env.DATABASE_URL){console.error('DATABASE_URL is required in production');process.exit(2);}
}

const store=createStore(); await store.init();
const existing=await store.getUserByUsername(bridgeUsername);
const pwHash=existing && process.env.BRIDGE_PASSWORD_ROTATE!=='1' ? existing.password_hash : await hashPassword(bridgePassword);
await store.upsertBootstrapUser({userId:existing?.user_id||`usr_${crypto.randomUUID()}`,username:bridgeUsername,passwordHash:pwHash});
const hub=new DeviceHub(store,{requestTimeoutMs,reconnectGraceMs});

function sendJson(res,code,obj,headers={}){res.writeHead(code,{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff','referrer-policy':'no-referrer',...headers});res.end(JSON.stringify(obj));}
function sendText(res,code,text,headers={}){res.writeHead(code,{'content-type':'text/plain; charset=utf-8','cache-control':'no-store',...headers});res.end(text);}
function h(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function sendHtml(res,code,title,body){const html=`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${h(title)}</title><style>body{font-family:system-ui;background:#0b0d10;color:#eef2f5;max-width:680px;margin:48px auto;padding:0 18px}form{display:grid;gap:12px;background:#15191f;padding:20px;border-radius:16px}input,button{font:inherit;padding:12px;border-radius:10px;border:1px solid #343b45;background:#0f1318;color:#fff}button{cursor:pointer;background:#fff;color:#111;font-weight:700}.muted{color:#9da8b5}.code{font-size:2rem;letter-spacing:.16em;font-weight:800}</style></head><body>${body}</body></html>`;res.writeHead(code,{'content-type':'text/html; charset=utf-8','cache-control':'no-store'});res.end(html);}
async function body(req,limit=1024*1024){const chunks=[];let n=0;for await(const c of req){n+=c.length;if(n>limit)throw Object.assign(new Error('body too large'),{status:413});chunks.push(c);}return Buffer.concat(chunks).toString('utf8');}
async function jsonBody(req,limit){const raw=await body(req,limit);try{return raw?JSON.parse(raw):{}}catch{throw Object.assign(new Error('invalid json'),{status:400});}}
async function formBody(req,limit){return Object.fromEntries(new URLSearchParams(await body(req,limit)));}
function getBearer(req){const m=/^Bearer\s+(.+)$/i.exec(req.headers.authorization||'');return m?m[1].trim():null;}
async function requireUser(req,res){const t=getBearer(req);if(!t){sendJson(res,401,{error:'unauthorized'},{'www-authenticate':`Bearer resource_metadata="${baseUrl}/.well-known/oauth-protected-resource/mcp"`});return null;}const row=await store.getAccessToken(sha256(t));if(!row){sendJson(res,401,{error:'invalid_token'},{'www-authenticate':`Bearer resource_metadata="${baseUrl}/.well-known/oauth-protected-resource/mcp"`});return null;}return row.user_id;}
const rl=new Map();function rateLimit(req,key,limit,windowMs){const now=Date.now(),id=`${key}:${req.socket.remoteAddress||'unknown'}`;let x=rl.get(id);if(!x||now-x.start>windowMs)x={start:now,count:0};x.count++;rl.set(id,x);return x.count<=limit;}
async function issueTokens(userId,clientId,res){const access=randomToken('atk_',32),refresh=randomToken('rtk_',40);await store.saveAccessToken({token_hash:sha256(access),user_id:userId,client_id:clientId,expires_at:futureIso(accessTtl)});await store.saveRefreshToken({token_hash:sha256(refresh),user_id:userId,client_id:clientId,expires_at:futureIso(refreshTtl)});sendJson(res,200,{access_token:access,token_type:'Bearer',expires_in:accessTtl,refresh_token:refresh});}
function toolResult(obj){return {content:[{type:'text',text:typeof obj==='string'?obj:JSON.stringify(obj,null,2)}],structuredContent:typeof obj==='object'&&obj?obj:{}};}

const server=http.createServer(async(req,res)=>{
  try{
    const url=new URL(req.url,baseUrl), p=url.pathname, method=req.method||'GET';
    if(method==='GET'&&p==='/health')return sendJson(res,200,{ok:true,service:'termux-android-remote-bridge',version:'0.3.2',time:new Date().toISOString()});
    if(method==='GET'&&p==='/')return sendText(res,200,'Termux Android Remote Bridge\n');
    if(method==='GET'&&(p==='/.well-known/oauth-protected-resource'||p==='/.well-known/oauth-protected-resource/mcp'))return sendJson(res,200,{resource:`${baseUrl}/mcp`,authorization_servers:[baseUrl],bearer_methods_supported:['header']});
    if(method==='GET'&&p==='/.well-known/oauth-authorization-server')return sendJson(res,200,{issuer:baseUrl,authorization_endpoint:`${baseUrl}/oauth/authorize`,token_endpoint:`${baseUrl}/oauth/token`,registration_endpoint:`${baseUrl}/oauth/register`,response_types_supported:['code'],grant_types_supported:['authorization_code','refresh_token'],code_challenge_methods_supported:['S256'],token_endpoint_auth_methods_supported:['none']});
    if(method==='POST'&&p==='/oauth/register'){
      if(!rateLimit(req,'oauth-register',30,60_000))return sendJson(res,429,{error:'rate_limited'});
      const b=await jsonBody(req,32*1024),uris=Array.isArray(b.redirect_uris)?b.redirect_uris.filter(x=>typeof x==='string'&&/^https?:\/\//.test(x)):[];
      if(!uris.length)return sendJson(res,400,{error:'invalid_redirect_uri'});
      const clientId=randomToken('client_',18);await store.createOAuthClient({client_id:clientId,client_name:String(b.client_name||'ChatGPT MCP Client').slice(0,120),redirect_uris:uris});return sendJson(res,201,{client_id:clientId,client_id_issued_at:Math.floor(Date.now()/1000),client_name:b.client_name||'ChatGPT MCP Client',redirect_uris:uris,grant_types:['authorization_code','refresh_token'],response_types:['code'],token_endpoint_auth_method:'none'});
    }
    if(method==='GET'&&p==='/oauth/authorize'){
      const q=Object.fromEntries(url.searchParams),c=await store.getOAuthClient(q.client_id),redirects=c?.redirect_uris||[];
      if(!c||!redirects.includes(q.redirect_uri)||q.response_type!=='code'||!q.code_challenge||q.code_challenge_method!=='S256')return sendHtml(res,400,'OAuth error','<h1>Ungültige OAuth-Anfrage</h1>');
      const hidden=Object.entries({client_id:q.client_id,redirect_uri:q.redirect_uri,state:q.state||'',code_challenge:q.code_challenge,code_challenge_method:q.code_challenge_method}).map(([k,v])=>`<input type="hidden" name="${k}" value="${h(v)}">`).join('');
      return sendHtml(res,200,'Termux Bridge Login',`<h1>Termux Android Bridge</h1><p class="muted">Melde dich an, damit ChatGPT auf deine verbundenen Geräte zugreifen darf.</p><form method="post" action="/oauth/authorize">${hidden}<input name="username" autocomplete="username" placeholder="Benutzername" required><input name="password" type="password" autocomplete="current-password" placeholder="Passwort" required><button type="submit">Verbinden</button></form>`);
    }
    if(method==='POST'&&p==='/oauth/authorize'){
      const b=await formBody(req,32*1024),c=await store.getOAuthClient(b.client_id),u=await store.getUserByUsername(b.username);
      if(!c||!(c.redirect_uris||[]).includes(b.redirect_uri)||!u||!(await verifyPassword(b.password||'',u.password_hash)))return sendHtml(res,401,'Login fehlgeschlagen','<h1>Login fehlgeschlagen</h1>');
      const code=randomToken('code_',28);await store.saveAuthCode({code_hash:sha256(code),client_id:b.client_id,user_id:u.user_id,redirect_uri:b.redirect_uri,code_challenge:b.code_challenge,expires_at:futureIso(300)});
      const dest=new URL(b.redirect_uri);dest.searchParams.set('code',code);if(b.state)dest.searchParams.set('state',b.state);res.writeHead(302,{location:dest.toString(),'cache-control':'no-store'});return res.end();
    }
    if(method==='POST'&&p==='/oauth/token'){
      const b=await formBody(req,32*1024);
      if(b.grant_type==='authorization_code'){
        const row=await store.consumeAuthCode(sha256(b.code||''));
        if(!row||Date.parse(row.expires_at)<=Date.now()||row.client_id!==b.client_id||row.redirect_uri!==b.redirect_uri||pkceS256(b.code_verifier||'')!==row.code_challenge)return sendJson(res,400,{error:'invalid_grant'});
        return issueTokens(row.user_id,row.client_id,res);
      }
      if(b.grant_type==='refresh_token'){
        const row=await store.consumeRefreshToken(sha256(b.refresh_token||''));if(!row||row.client_id!==b.client_id)return sendJson(res,400,{error:'invalid_grant'});return issueTokens(row.user_id,row.client_id,res);
      }
      return sendJson(res,400,{error:'unsupported_grant_type'});
    }
    if(method==='POST'&&p==='/api/pair/request'){
      if(!rateLimit(req,'pair-request',20,60_000))return sendJson(res,429,{error:'rate_limited'});
      const b=await jsonBody(req,32*1024),deviceId=String(b.device_id||'').trim();if(!/^[A-Za-z0-9._:-]{8,128}$/.test(deviceId))return sendJson(res,400,{error:'invalid_device_id'});
      const metadata={device_name:String(b.device_name||'Android Device').slice(0,120),device_type:String(b.device_type||'phone').slice(0,40),platform:String(b.platform||'android-termux').slice(0,80),app_version:String(b.app_version||'unknown').slice(0,40),capabilities:Array.isArray(b.capabilities)?b.capabilities.slice(0,50):[]};
      let code=randomCode(6);for(let i=0;i<8&&(await store.getPairingByCode(code));i++)code=randomCode(6);
      const pairingId=crypto.randomUUID(),nonce=randomToken('pair_',24);await store.createPairing({pairing_id:pairingId,pair_code:code,nonce_hash:sha256(nonce),device_id:deviceId,metadata,created_at:nowIso(),expires_at:futureIso(pairTtl)});
      return sendJson(res,200,{pairing_id:pairingId,pairing_nonce:nonce,pairing_code:code,claim_url:`${baseUrl}/pair?code=${encodeURIComponent(code)}`,expires_in:pairTtl});
    }
    if(method==='GET'&&p==='/pair'){
      const code=String(url.searchParams.get('code')||'').toUpperCase();return sendHtml(res,200,'Gerät koppeln',`<h1>Termux-Gerät koppeln</h1><p class="muted">Gib deinen Bridge-Login ein und bestätige den Code.</p><form method="post" action="/pair"><input name="code" value="${h(code)}" placeholder="Pairing-Code" required><input name="username" autocomplete="username" placeholder="Benutzername" required><input name="password" type="password" autocomplete="current-password" placeholder="Passwort" required><button type="submit">Gerät verbinden</button></form>`);
    }
    if(method==='POST'&&p==='/pair'){
      const b=await formBody(req,32*1024),code=String(b.code||'').toUpperCase(),pair=await store.getPairingByCode(code);
      if(!pair||Date.parse(pair.expires_at)<=Date.now()||pair.claimed_at)return sendHtml(res,400,'Pairing fehlgeschlagen','<h1>Code ungültig oder abgelaufen.</h1>');
      const u=await store.getUserByUsername(String(b.username||''));if(!u||!(await verifyPassword(String(b.password||''),u.password_hash)))return sendHtml(res,401,'Login fehlgeschlagen','<h1>Login fehlgeschlagen.</h1>');
      const deviceToken=randomToken('dev_',40);await store.upsertDevice({device_id:pair.device_id,user_id:u.user_id,device_name:pair.metadata?.device_name||'Android Device',device_type:pair.metadata?.device_type||'phone',platform:pair.metadata?.platform||'android-termux',app_version:pair.metadata?.app_version||'unknown',token_hash:sha256(deviceToken),token_version:1,connected:false,capabilities:pair.metadata?.capabilities||[]});await store.claimPairing(pair.pairing_id,{claimed_user_id:u.user_id,claimed_at:nowIso(),issued_token_enc:encryptString(deviceToken,serverSecret)});return sendHtml(res,200,'Gerät verbunden',`<h1>Gerät verbunden ✅</h1><p>${h(pair.metadata?.device_name||pair.device_id)} darf sich jetzt verbinden.</p><p class="muted">Das Device-Token wird ausschließlich an den wartenden Termux-Client ausgeliefert.</p>`);
    }
    if(method==='POST'&&p==='/api/pair/status'){
      const b=await jsonBody(req,16*1024),pair=await store.getPairing(String(b.pairing_id||''));if(!pair||sha256(String(b.pairing_nonce||''))!==pair.nonce_hash)return sendJson(res,404,{error:'pairing_not_found'});if(Date.parse(pair.expires_at)<=Date.now())return sendJson(res,410,{status:'expired'});if(!pair.claimed_at)return sendJson(res,200,{status:'pending',expires_at:pair.expires_at});if(pair.delivered_at||!pair.issued_token_enc)return sendJson(res,410,{status:'already_delivered'});const token=decryptString(pair.issued_token_enc,serverSecret);await store.markPairDelivered(pair.pairing_id);return sendJson(res,200,{status:'paired',device_id:pair.device_id,device_token:token,user_id:pair.claimed_user_id});
    }
    if(method==='POST'&&p==='/api/device/token/rotate'){
      const t=getBearer(req);if(!t)return sendJson(res,401,{error:'unauthorized'});const d=await store.getDeviceByToken(sha256(t));if(!d)return sendJson(res,401,{error:'invalid_device_token'});const next=randomToken('dev_',40);await store.rotateDeviceToken(d.device_id,sha256(next));return sendJson(res,200,{device_token:next,device_id:d.device_id});
    }
    if(method==='POST'&&p==='/api/device/revoke-self'){
      const t=getBearer(req);if(!t)return sendJson(res,401,{error:'unauthorized'});const d=await store.getDeviceByToken(sha256(t));if(!d)return sendJson(res,401,{error:'invalid_device_token'});await store.revokeDevice(d.user_id,d.device_id);hub.disconnectNow(d.device_id);return sendJson(res,200,{revoked:true,device_id:d.device_id});
    }
    if(method==='GET'&&p==='/api/devices'){
      const userId=await requireUser(req,res);if(!userId)return;const ds=await store.listDevices(userId);return sendJson(res,200,{devices:ds.map(d=>({device_id:d.device_id,device_name:d.device_name,device_type:d.device_type,platform:d.platform,app_version:d.app_version,connected:!!d.connected,last_seen:d.last_seen,session_id:d.session_id,capabilities:d.capabilities,revoked:!!d.revoked_at}))});
    }
    const revoke=/^\/api\/devices\/([^/]+)\/revoke$/.exec(p);
    if(method==='POST'&&revoke){const userId=await requireUser(req,res);if(!userId)return;const id=decodeURIComponent(revoke[1]);const ok=await store.revokeDevice(userId,id);if(ok)hub.disconnectNow(id);return sendJson(res,ok?200:404,ok?{revoked:true,device_id:id}:{error:'device_not_found'});}
    if(p==='/mcp'){
      if(method!=='POST')return sendText(res,405,'MCP uses Streamable HTTP POST.\n',{allow:'POST'});
      if(!rateLimit(req,'mcp',240,60_000))return sendJson(res,429,{error:'rate_limited'});const userId=await requireUser(req,res);if(!userId)return;const msg=await jsonBody(req,1024*1024),base={jsonrpc:'2.0',id:msg.id??null};
      if(msg.method==='initialize')return sendJson(res,200,{...base,result:{protocolVersion:'2025-03-26',capabilities:{tools:{listChanged:false}},serverInfo:{name:'termux-android-remote-bridge',version:'0.3.2'},instructions:'Routes MCP requests to authenticated Termux devices over persistent WSS. Never fabricate device output.'}});
      if(msg.method==='notifications/initialized'){res.writeHead(202);return res.end();}
      if(msg.method==='ping')return sendJson(res,200,{...base,result:{}});
      if(msg.method==='tools/list')return sendJson(res,200,{...base,result:{tools:MCP_TOOLS}});
      if(msg.method==='tools/call'){
        const name=msg.params?.name,args=msg.params?.arguments||{};
        try{
          if(name==='termux_status'){
            const ds=await store.listDevices(userId),online=hub.onlineSnapshot(userId);
            if(args.device_id){const d=await store.getDevice(userId,args.device_id);if(!d)throw Object.assign(new Error('Device not found.'),{code:'DEVICE_NOT_FOUND'});if(!online.some(x=>x.device_id===d.device_id))return sendJson(res,200,{...base,result:toolResult({connected:false,device_id:d.device_id,device_name:d.device_name,last_seen:d.last_seen,platform:d.platform,app_version:d.app_version})});const routed=await hub.route(userId,'termux_status',{}, {deviceId:d.device_id,timeoutMs:30000});return sendJson(res,200,{...base,result:toolResult({...routed.result,request_id:routed.request_id,device_id:routed.device_id})});}
            if(online.length===1){const routed=await hub.route(userId,'termux_status',{}, {deviceId:online[0].device_id,timeoutMs:30000});return sendJson(res,200,{...base,result:toolResult({...routed.result,request_id:routed.request_id,device_id:routed.device_id})});}
            return sendJson(res,200,{...base,result:toolResult({connected_devices:online,known_devices:ds.map(d=>({device_id:d.device_id,device_name:d.device_name,connected:!!d.connected,last_seen:d.last_seen}))})});
          }
          if(!MCP_TOOLS.some(t=>t.name===name))throw Object.assign(new Error(`Unknown tool: ${name}`),{code:'UNKNOWN_TOOL'});
          const deviceId=args.device_id,forwarded={...args};delete forwarded.device_id;const timeoutMs=name==='termux_run'?Math.min(310000,((forwarded.timeout_seconds||180)+10)*1000):60000;const routed=await hub.route(userId,name,forwarded,{deviceId,timeoutMs});return sendJson(res,200,{...base,result:toolResult({...routed.result,request_id:routed.request_id,device_id:routed.device_id})});
        }catch(e){return sendJson(res,200,{...base,result:{content:[{type:'text',text:JSON.stringify({code:e.code||'RELAY_ERROR',message:e.message,details:e.details||null},null,2)}],isError:true}});}
      }
      return sendJson(res,200,{...base,error:{code:-32601,message:'Method not found'}});
    }
    return sendJson(res,404,{error:'not_found'});
  }catch(e){console.error('[http]',e.message);return sendJson(res,e.status||500,{error:e.status?'bad_request':'internal_error'});}
});

const wss=new WebSocketServer({noServer:true,maxPayload:1024*1024});
server.on('upgrade',(req,socket,head)=>{try{const u=new URL(req.url,baseUrl);if(u.pathname!=='/device'){socket.destroy();return;}wss.handleUpgrade(req,socket,head,ws=>wss.emit('connection',ws,req));}catch{socket.destroy();}});
wss.on('connection',(ws)=>{
  ws.isAlive=true;let registered=false,device=null;
  ws.on('pong',()=>{ws.isAlive=true;if(device)hub.touch(device.device_id).catch(()=>{});});
  ws.on('message',async data=>{let msg;try{msg=JSON.parse(data.toString())}catch{return}if(!registered){if(msg.type!=='auth'||!msg.device_token){ws.close(4003,'authentication required');return;}device=await store.getDeviceByToken(sha256(msg.device_token));if(!device){ws.close(4003,'invalid device token');return;}registered=true;await hub.register(device,ws,msg);return;}hub.handleMessage(device.device_id,ws,msg);});
  ws.on('close',()=>{if(device)hub.disconnect(device.device_id,ws).catch(()=>{});});ws.on('error',()=>{});
});
const ping=setInterval(()=>{for(const ws of wss.clients){if(ws.isAlive===false){try{ws.terminate()}catch{};continue;}ws.isAlive=false;try{ws.ping()}catch{}}},20000);ping.unref();
server.listen(PORT,'0.0.0.0',()=>console.log(`Termux Android Remote Bridge listening on ${PORT}; public base ${baseUrl}`));
