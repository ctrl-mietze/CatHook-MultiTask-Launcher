#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail
IFS=$'\n\t'

SCRIPT_VERSION="1.0.0"
BASE_DIR="$HOME/.termux-android-bridge"
TUNNEL_DIR="$BASE_DIR/tunnel"
BRIDGE_ENV="$BASE_DIR/.env"
BRIDGE_START="$BASE_DIR/start.sh"
TUNNEL_ENV="$TUNNEL_DIR/tunnel.env"
TUNNEL_LOG_DIR="$TUNNEL_DIR/logs"
CLIENT_BIN="$PREFIX/bin/tunnel-client"
MANAGER_BIN="$PREFIX/bin/termux-android-tunnel"
LOCAL_MCP_URL="http://127.0.0.1:8765/mcp"
HEALTH_ADDR="127.0.0.1:8788"
FALLBACK_TAG="v0.0.14"

say()  { printf '\n[INFO] %s\n' "$*"; }
ok()   { printf '[ OK ] %s\n' "$*"; }
warn() { printf '[WARN] %s\n' "$*"; }
die()  { printf '[FAIL] %s\n' "$*" >&2; exit 1; }

cleanup_tmp=""
cleanup() {
  if [ -n "${cleanup_tmp:-}" ] && [ -d "$cleanup_tmp" ]; then
    rm -rf "$cleanup_tmp"
  fi
}
trap cleanup EXIT

if [ ! -d "/data/data/com.termux/files/usr" ] || [ -z "${PREFIX:-}" ]; then
  die "Dieses Setup ist fuer Termux gedacht."
fi

say "Termux Secure MCP Tunnel Setup v$SCRIPT_VERSION"
printf 'Ziel: OpenAI Secure MCP Tunnel -> lokaler MCP-Server %s\n' "$LOCAL_MCP_URL"

say "Installiere lokale Abhaengigkeiten"
pkg update -y
pkg install -y curl jq unzip coreutils ca-certificates
ok "Abhaengigkeiten bereit"

mkdir -p "$TUNNEL_DIR" "$TUNNEL_LOG_DIR"
chmod 700 "$TUNNEL_DIR" "$TUNNEL_LOG_DIR"

if [ ! -f "$BRIDGE_ENV" ]; then
  if command -v termux-android-bridge >/dev/null 2>&1; then
    say "Bridge-Konfiguration fehlt; starte Bridge-Setup"
    termux-android-bridge setup || true
  fi
fi
[ -f "$BRIDGE_ENV" ] || die "Bridge-Konfiguration fehlt: $BRIDGE_ENV. Installiere/konfiguriere zuerst Termux Android Bridge."
[ -f "$BRIDGE_START" ] || die "Bridge-Startscript fehlt: $BRIDGE_START"

# Secure Tunnel braucht keine LAN-Freigabe. Den lokalen MCP-Listener auf Loopback begrenzen.
if grep -q '^BRIDGE_HOST=' "$BRIDGE_ENV"; then
  current_host="$(grep '^BRIDGE_HOST=' "$BRIDGE_ENV" | tail -n1 | cut -d= -f2-)"
  if [ "$current_host" != "127.0.0.1" ]; then
    cp "$BRIDGE_ENV" "$BRIDGE_ENV.before-secure-tunnel"
    sed -i 's/^BRIDGE_HOST=.*/BRIDGE_HOST=127.0.0.1/' "$BRIDGE_ENV"
    ok "BRIDGE_HOST auf 127.0.0.1 begrenzt (Backup: $BRIDGE_ENV.before-secure-tunnel)"
  fi
else
  printf '\nBRIDGE_HOST=127.0.0.1\n' >> "$BRIDGE_ENV"
  ok "BRIDGE_HOST=127.0.0.1 gesetzt"
fi
chmod 600 "$BRIDGE_ENV"

case "$(uname -m)" in
  aarch64|arm64) release_platform="linux-arm64" ;;
  x86_64|amd64) release_platform="linux-amd64" ;;
  *) die "Nicht unterstuetzte CPU-Architektur: $(uname -m)" ;;
esac

install_tunnel_client() {
  say "Lade den offiziellen OpenAI tunnel-client ($release_platform)"
  cleanup_tmp="$(mktemp -d "${TMPDIR:-$PREFIX/tmp}/termux-tunnel.XXXXXX")"
  meta="$cleanup_tmp/release.json"
  zipfile="$cleanup_tmp/tunnel-client.zip"
  sums="$cleanup_tmp/SHA256SUMS.txt"

  tag=""
  asset_url=""
  asset_name=""
  sums_url=""

  if curl -fsSL --retry 3 --connect-timeout 15 \
      -H 'Accept: application/vnd.github+json' \
      -H 'User-Agent: Termux-Android-Bridge-Tunnel-Setup' \
      'https://api.github.com/repos/openai/tunnel-client/releases/latest' -o "$meta"; then
    tag="$(jq -r '.tag_name // empty' "$meta")"
    asset_url="$(jq -r --arg p "$release_platform" '.assets[] | select((.name | startswith("tunnel-client-v")) and (.name | endswith("-" + $p + ".zip"))) | .browser_download_url' "$meta" | head -n1)"
    asset_name="$(jq -r --arg p "$release_platform" '.assets[] | select((.name | startswith("tunnel-client-v")) and (.name | endswith("-" + $p + ".zip"))) | .name' "$meta" | head -n1)"
    sums_url="$(jq -r '.assets[] | select(.name == "SHA256SUMS.txt") | .browser_download_url' "$meta" | head -n1)"
  fi

  if [ -z "$asset_url" ] || [ -z "$asset_name" ] || [ -z "$sums_url" ]; then
    warn "GitHub-API-Metadaten nicht vollstaendig erreichbar; verwende validierten Fallback $FALLBACK_TAG."
    tag="$FALLBACK_TAG"
    asset_name="tunnel-client-${tag}-${release_platform}.zip"
    base="https://github.com/openai/tunnel-client/releases/download/${tag}"
    asset_url="$base/$asset_name"
    sums_url="$base/SHA256SUMS.txt"
  fi

  printf '[INFO] Release: %s\n' "$tag"
  printf '[INFO] Asset:   %s\n' "$asset_name"
  curl -fL --retry 3 --connect-timeout 20 "$asset_url" -o "$zipfile" || die "Download des tunnel-client fehlgeschlagen."
  curl -fL --retry 3 --connect-timeout 20 "$sums_url" -o "$sums" || die "Download der SHA256SUMS fehlgeschlagen."

  expected="$(awk -v n="$asset_name" '$2==n || $2=="*"n {print $1; exit}' "$sums")"
  [ -n "$expected" ] || die "Kein SHA256-Eintrag fuer $asset_name gefunden."
  actual="$(sha256sum "$zipfile" | awk '{print $1}')"
  [ "$actual" = "$expected" ] || die "SHA256-Pruefung fehlgeschlagen. Erwartet $expected, erhalten $actual"
  ok "SHA256 verifiziert"

  mkdir -p "$cleanup_tmp/unpack"
  unzip -q "$zipfile" -d "$cleanup_tmp/unpack"
  candidate="$(find "$cleanup_tmp/unpack" -type f -name tunnel-client | head -n1)"
  [ -n "$candidate" ] || die "tunnel-client Binary nicht im Archiv gefunden."

  cp "$candidate" "$CLIENT_BIN"
  chmod 700 "$CLIENT_BIN"
  if ! "$CLIENT_BIN" --version; then
    rm -f "$CLIENT_BIN"
    die "Die offizielle Linux-Binary startet in dieser Termux-Umgebung nicht. In diesem Fall muessen wir den Client fuer Android/Termux aus Source bauen."
  fi
  ok "tunnel-client installiert: $CLIENT_BIN"
}

if [ ! -x "$CLIENT_BIN" ]; then
  install_tunnel_client
else
  say "Vorhandener tunnel-client gefunden"
  "$CLIENT_BIN" --version || install_tunnel_client
fi

write_manager() {
  cat > "$MANAGER_BIN" <<'MANAGER'
#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail
IFS=$'\n\t'
BASE_DIR="$HOME/.termux-android-bridge"
TUNNEL_DIR="$BASE_DIR/tunnel"
BRIDGE_ENV="$BASE_DIR/.env"
BRIDGE_START="$BASE_DIR/start.sh"
TUNNEL_ENV="$TUNNEL_DIR/tunnel.env"
LOG_DIR="$TUNNEL_DIR/logs"
PID_FILE="$TUNNEL_DIR/bridge.pid"
LOCAL_MCP_URL="http://127.0.0.1:8765/mcp"
HEALTH_ADDR="127.0.0.1:8788"

say(){ printf '\n[INFO] %s\n' "$*"; }
ok(){ printf '[ OK ] %s\n' "$*"; }
warn(){ printf '[WARN] %s\n' "$*"; }
die(){ printf '[FAIL] %s\n' "$*" >&2; exit 1; }

load_bridge_env() {
  [ -f "$BRIDGE_ENV" ] || die "Bridge env fehlt: $BRIDGE_ENV"
  set -a
  . "$BRIDGE_ENV"
  set +a
  [ -n "${BRIDGE_TOKEN:-}" ] || die "BRIDGE_TOKEN fehlt."
}

load_tunnel_env() {
  [ -f "$TUNNEL_ENV" ] || die "Tunnel ist noch nicht konfiguriert. Nutze: termux-android-tunnel setup"
  set -a
  . "$TUNNEL_ENV"
  set +a
  [ -n "${CONTROL_PLANE_TUNNEL_ID:-}" ] || die "CONTROL_PLANE_TUNNEL_ID fehlt."
  [ -n "${CONTROL_PLANE_API_KEY:-}" ] || die "CONTROL_PLANE_API_KEY fehlt."
}

export_runtime() {
  load_bridge_env
  load_tunnel_env
  export TERMUX_BRIDGE_AUTH="Bearer ${BRIDGE_TOKEN}"
  export MCP_SERVER_URL="$LOCAL_MCP_URL"
  export MCP_EXTRA_HEADERS='Authorization: env:TERMUX_BRIDGE_AUTH'
  export MCP_DISCOVERY_EXTRA_HEADERS='Authorization: env:TERMUX_BRIDGE_AUTH'
  export MCP_STARTUP_WAIT_TIMEOUT='30s'
}

bridge_alive() {
  curl -fsS --max-time 2 'http://127.0.0.1:8765/health' >/dev/null 2>&1
}

ensure_bridge() {
  if bridge_alive; then
    ok "Termux Android Bridge laeuft bereits."
    return 0
  fi
  [ -x "$BRIDGE_START" ] || chmod 700 "$BRIDGE_START" 2>/dev/null || true
  [ -f "$BRIDGE_START" ] || die "Bridge start.sh fehlt: $BRIDGE_START"
  mkdir -p "$LOG_DIR"
  say "Starte lokalen MCP-Server auf 127.0.0.1:8765"
  bash "$BRIDGE_START" >>"$LOG_DIR/bridge.log" 2>&1 &
  bridge_pid=$!
  printf '%s\n' "$bridge_pid" > "$PID_FILE"
  for _ in 1 2 3 4 5 6 7 8 9 10; do
    if bridge_alive; then
      ok "Bridge ist erreichbar (PID $bridge_pid)."
      return 0
    fi
    sleep 0.5
  done
  tail -n 40 "$LOG_DIR/bridge.log" 2>/dev/null || true
  die "Bridge konnte nicht gestartet werden."
}

setup_creds() {
  mkdir -p "$TUNNEL_DIR" "$LOG_DIR"
  chmod 700 "$TUNNEL_DIR" "$LOG_DIR"
  printf '\nOpenAI Secure MCP Tunnel Zugangsdaten\n'
  printf 'Tunnel-Verwaltung: https://platform.openai.com/settings/organization/tunnels\n'
  printf 'Runtime API Keys:  https://platform.openai.com/settings/organization/api-keys\n\n'
  read -r -p 'Tunnel ID (tunnel_...): ' tunnel_id
  [ -n "$tunnel_id" ] || die "Tunnel ID darf nicht leer sein."
  case "$tunnel_id" in tunnel_*) ;; *) die "Tunnel ID muss mit tunnel_ beginnen." ;; esac
  read -r -s -p 'Runtime API Key: ' runtime_key
  printf '\n'
  [ -n "$runtime_key" ] || die "Runtime API Key darf nicht leer sein."
  umask 077
  cat > "$TUNNEL_ENV" <<EOF_CREDS
CONTROL_PLANE_TUNNEL_ID='$tunnel_id'
CONTROL_PLANE_API_KEY='$runtime_key'
EOF_CREDS
  chmod 600 "$TUNNEL_ENV"
  ok "Zugangsdaten lokal gespeichert: $TUNNEL_ENV (0600)"
}

status_cmd() {
  printf '=== Termux Android Bridge / Secure MCP Tunnel ===\n'
  if bridge_alive; then ok "Lokaler MCP-Server: erreichbar"; else warn "Lokaler MCP-Server: nicht erreichbar"; fi
  if curl -fsS --max-time 2 "http://$HEALTH_ADDR/healthz" >/dev/null 2>&1; then
    ok "tunnel-client /healthz: erreichbar"
  else
    warn "tunnel-client /healthz: nicht erreichbar (Tunnel vermutlich nicht gestartet)"
  fi
  [ -f "$TUNNEL_ENV" ] && ok "Tunnel-Konfiguration vorhanden" || warn "Tunnel-Konfiguration fehlt"
  tunnel-client --version 2>/dev/null || true
}

stop_bridge() {
  if [ -f "$PID_FILE" ]; then
    pid="$(cat "$PID_FILE" 2>/dev/null || true)"
    if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
      kill "$pid" 2>/dev/null || true
      sleep 0.5
      kill -9 "$pid" 2>/dev/null || true
      ok "Von diesem Manager gestartete Bridge gestoppt (PID $pid)."
    fi
    rm -f "$PID_FILE"
  else
    warn "Keine von diesem Manager gespeicherte Bridge-PID vorhanden."
  fi
}

cmd="${1:-help}"
case "$cmd" in
  setup)
    setup_creds
    ;;
  doctor)
    ensure_bridge
    export_runtime
    say "Fuehre OpenAI tunnel-client doctor aus"
    exec tunnel-client doctor --explain
    ;;
  start)
    ensure_bridge
    export_runtime
    if command -v termux-wake-lock >/dev/null 2>&1; then termux-wake-lock >/dev/null 2>&1 || true; fi
    say "Starte Secure MCP Tunnel im Vordergrund"
    printf 'Tunnel ID: %s\n' "$CONTROL_PLANE_TUNNEL_ID"
    printf 'Lokaler MCP: %s\n' "$MCP_SERVER_URL"
    printf 'Admin UI: http://%s/ui\n\n' "$HEALTH_ADDR"
    exec tunnel-client run --health.listen-addr "$HEALTH_ADDR"
    ;;
  status)
    status_cmd
    ;;
  ui|open-ui)
    url="http://$HEALTH_ADDR/ui"
    if command -v termux-open-url >/dev/null 2>&1; then termux-open-url "$url"; else printf '%s\n' "$url"; fi
    ;;
  stop-bridge)
    stop_bridge
    ;;
  show-id)
    load_tunnel_env
    printf '%s\n' "$CONTROL_PLANE_TUNNEL_ID"
    ;;
  logs)
    mkdir -p "$LOG_DIR"
    tail -n 120 "$LOG_DIR/bridge.log" 2>/dev/null || true
    ;;
  help|-h|--help)
    cat <<'EOF_HELP'
Termux Android Tunnel Manager

Commands:
  termux-android-tunnel setup        Tunnel ID + Runtime API Key lokal setzen
  termux-android-tunnel doctor       Bridge starten/pruefen + Tunnel-Diagnose
  termux-android-tunnel start        Bridge + OpenAI Secure MCP Tunnel starten
  termux-android-tunnel status       Lokalen Status pruefen
  termux-android-tunnel open-ui      Lokale tunnel-client Admin-UI oeffnen
  termux-android-tunnel show-id      Nur die Tunnel-ID anzeigen (nie den API-Key)
  termux-android-tunnel logs         Letzte Bridge-Logs anzeigen
  termux-android-tunnel stop-bridge  Nur die vom Manager gestartete Bridge stoppen

Wichtig: tunnel-client laeuft absichtlich im Vordergrund. So bleibt sichtbar, ob der
Tunnel gesund ist. Der MCP-Server bleibt auf 127.0.0.1 und wird nicht ins LAN geoeffnet.
EOF_HELP
    ;;
  *) die "Unbekannter Befehl: $cmd (nutze: termux-android-tunnel help)" ;;
esac
MANAGER
  chmod 700 "$MANAGER_BIN"
}

write_manager
ok "Manager installiert: $MANAGER_BIN"

cat > "$TUNNEL_DIR/README.txt" <<'EOF_README'
Termux Android Bridge - OpenAI Secure MCP Tunnel

1) Erzeuge/waehle einen Tunnel in:
   https://platform.openai.com/settings/organization/tunnels
2) Erzeuge einen Runtime API Key mit Tunnels Read + Use:
   https://platform.openai.com/settings/organization/api-keys
3) In Termux:
   termux-android-tunnel setup
   termux-android-tunnel doctor
   termux-android-tunnel start
4) In ChatGPT Developer Mode beim MCP/Plugin die Verbindung "Tunnel" waehlen
   und die gleiche tunnel_... ID auswaehlen/eintragen.

Lokaler MCP-Endpunkt: http://127.0.0.1:8765/mcp
Lokale Admin-UI:      http://127.0.0.1:8788/ui
EOF_README
chmod 600 "$TUNNEL_DIR/README.txt"

say "Setup-Dateien sind fertig"
printf 'Manager: %s\n' "$MANAGER_BIN"
printf 'Config:  %s\n' "$TUNNEL_ENV"
printf 'Docs:    %s\n' "$TUNNEL_DIR/README.txt"
printf '\n'

read -r -p 'Hast du bereits eine OpenAI tunnel_... ID und einen Runtime API Key? [j/N] ' have_creds
case "${have_creds:-n}" in
  j|J|ja|JA|y|Y|yes|YES)
    "$MANAGER_BIN" setup
    say "Teste jetzt die Konfiguration"
    "$MANAGER_BIN" doctor || {
      warn "Doctor meldet noch einen Fehler. Das Setup selbst ist installiert; nach Korrektur erneut ausfuehren: termux-android-tunnel doctor"
      exit 0
    }
    ok "Tunnel-Konfiguration ist bereit. Starte mit: termux-android-tunnel start"
    ;;
  *)
    printf '\nNoch keine Zugangsdaten gespeichert. Erzeuge sie in der OpenAI Platform und fuehre danach aus:\n'
    printf '  termux-android-tunnel setup\n'
    printf '  termux-android-tunnel doctor\n'
    printf '  termux-android-tunnel start\n'
    ;;
esac
