# Termux Android Remote Bridge

A real outbound remote bridge between ChatGPT and Termux.

Architecture:

```text
ChatGPT / MCP client
        |
        | HTTPS Streamable MCP + OAuth 2.1
        v
Public Relay (Railway)
        |
        | persistent authenticated WSS
        v
Termux Android Client
        |
        +-- termux_status
        +-- termux_run
        +-- termux_list_audits
        +-- termux_read_audit
        +-- termux_save_audit
```

The Android device never exposes a private IP or listening port. It creates the outbound WSS connection itself, so the design works through NAT, CGNAT, mobile data, WLAN, IPv4 and IPv6 changes.

## No OpenAI API key for device transport

The device side does **not** use OpenAI Secure MCP Tunnel, `CONTROL_PLANE_API_KEY`, an OpenAI Runtime API key, or OpenAI API credits. ChatGPT talks to the public MCP endpoint; the relay routes requests to the already connected device.

## Relay deployment

The repository is Railway-ready. Required production variables:

- `PUBLIC_BASE_URL=https://<your-railway-domain>`
- `ADMIN_USERNAME=<your-login>`
- `ADMIN_PASSWORD=<strong-password>`
- `TOKEN_PEPPER=<at-least-32-random-characters>`
- `DATA_DIR=/data`
- `NODE_ENV=production`

Attach a persistent Railway volume at `/data` so paired devices and OAuth tokens survive redeploys.

Health endpoint: `/health`

MCP endpoint: `/mcp`

Device WebSocket: `/device`

## Termux package

The client is packaged as `termux-android-bridge` and is distributed through the CatHook Termux APT feed.

After the CatHook repo bootstrap package is installed once:

```bash
pkg update
pkg install termux-android-bridge
```

Then pair it:

```bash
termux-android-bridge setup --relay https://<your-railway-domain>
```

The client prints a one-time pairing code and opens the approval page when `termux-open-url` is available. The issued device token is stored only in:

```text
~/.termux-android-bridge/auth.json
```

with mode `0600`.

Normal commands:

```bash
termux-android-bridge start
termux-android-bridge stop
termux-android-bridge status
termux-android-bridge doctor
termux-android-bridge logs
termux-android-bridge rotate-token
termux-android-bridge logout
```

## Security model

- TLS/WSS in production
- OAuth 2.1 + PKCE for MCP user authentication
- per-device random bearer tokens, stored hashed server-side
- device tokens bound to one user and one device ID
- request IDs and session IDs
- replay rejection on the device
- bounded command timeouts and output
- rate limits
- token rotation and self-revoke
- no secrets written to normal logs
- normal Termux app-user permissions by default; root is never implicit

## Audit storage

The client resolves Android shared storage and creates `Documents/AuditAi` when needed. `termux_save_audit` uses unique filenames and never overwrites existing reports.

## Tests

The integration test starts the relay, pairs a simulated Android client, completes OAuth, calls MCP `termux_run`, and verifies that the command result came back through the WSS route.

```bash
node tests/integration.mjs
```
